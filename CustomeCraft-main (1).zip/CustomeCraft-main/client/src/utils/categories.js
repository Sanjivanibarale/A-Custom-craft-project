export const categories = [
  { name: "Select",logo: "/service-1.svg" },
  { name: "Nippan Art", logo: "/service-2.svg" },
  { name: "Writing & Translation", logo: "/service-3.svg" },
  { name: "Video & Animation", logo: "/service-4.svg" },
  { name: "Resin Art", logo: "/service-5.svg" },
  { name: "String Art", logo: "/service-6.svg" },
  { name: "Business", logo: "/service-7.svg" },
  { name: "Lifestyle", logo: "/service-8.svg" },
  { name: "Diet", logo: "/service-9.svg" },
  { name: "Photography", logo: "/service-10.svg" },
];
