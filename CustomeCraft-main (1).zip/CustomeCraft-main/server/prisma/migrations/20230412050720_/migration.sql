-- AlterTable
ALTER TABLE "User" ALTER COLUMN "isSocialLogin" SET DEFAULT false;
